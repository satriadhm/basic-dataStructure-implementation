#include "member.h"

int main()
{
    member M;
    inputData(M);
    showData(M);

    cout << "Dengan Rata-Rata Poin: " << ratarata(M) << endl;
    return 0;
}
