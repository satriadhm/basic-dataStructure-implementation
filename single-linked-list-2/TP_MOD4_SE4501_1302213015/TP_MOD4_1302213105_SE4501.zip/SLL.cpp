#include "SLL.h"
void CreateList (List &gi) {
    first(gi) = nil;
}
adr newElement (infotype x ) {
    adr p = new element;
    info(p) = x;
    next(p) = nil;
    return p;
}
void insertFirst (List &gi, adr p) {
    if (first(gi) == nil){
            first(gi) = p;
    }else{
            next(p) = first(gi);
            first(gi) = p;
    }
}
void show (List gi){
    adr p;
    if (first(gi) != nil){
        p = first(gi);
        while ( p != nil)
        {
            cout << info(p) << " ";
            p = next(p);
        }
    }else {
    cout << "List Kosong." << endl;
    }
    cout << endl;
}
adr deleteLast (List &gi){
    adr p, q;
    if ( first(gi) == nil ) {
        p = nil;
        cout << "List Kosong.";
    }else if (next(first(gi)) == nil) {
        p = first(gi);
        first(gi) = nil;
    }else {
        q = first(gi);
        p = first(gi);
        while ( next(p) != nil) {
            q = p;
            p = next(p);
        }
        next(q) = nil;
        return p;
    }
}
